<html>
<head>
<title>Article List</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default">

  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">TP2K16</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a class="nav-link" href="<?php echo base_url()?>export">User FeedbacK<span class="sr-only">(current)</span></a></li>
      <li><a class="nav-link"  href="<?php echo base_url()?>Dynamic_dependent">Drop Down Demo</a></li>
     <li class="active"><a class="nav-link"  href="<?php echo base_url()?>login">Admin Login</a></li>
    </ul>
  </div>
</nav>

